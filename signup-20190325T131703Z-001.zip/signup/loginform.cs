﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace signup
{
    public partial class loginform : Form
    {
        public loginform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string constring = "server=.;database=mydb;user=sa;password=aptech;";
                SqlConnection cn = new SqlConnection(constring);
                cn.Open();
                string query = "select * from mytb where u_name='" + textBox1.Text + "' and u_pass='" + textBox2.Text + "'";
                SqlCommand cmd = new SqlCommand(query, cn);
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.HasRows)
                {
                    MessageBox.Show("Login Succesfull");
                }
                else
                {
                    MessageBox.Show("Login Failed");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
