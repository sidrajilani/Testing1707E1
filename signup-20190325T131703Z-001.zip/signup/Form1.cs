﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace signup
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
            string constring = "server=.;database=mydb;user=sa;password=aptech;";
            SqlConnection cn = new SqlConnection(constring);
            cn.Open();
            string query = "insert into mytb(u_name,u_pass,age,joining_date) values ('" + textBox1.Text + "','" + textBox2.Text + "','" + Convert.ToInt16(textBox3.Text) + "','" + Convert.ToDateTime(dateTimePicker1.Text) + "')";
            SqlCommand cmd = new SqlCommand(query, cn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Account Genrated");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            loginform obj = new loginform();
            obj.Show();
        }
    }
}
